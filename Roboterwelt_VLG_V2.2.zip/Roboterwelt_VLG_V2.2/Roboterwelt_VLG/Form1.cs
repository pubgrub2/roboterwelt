﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roboterwelt_VLG
{
    public partial class Form1 : Form
    {
        // Hier werden die Elemente erzeugt...
        Welt w = new Welt(10, 12);
        
        public Form1()
        {
            InitializeComponent();
            Initialize();
            //.... und hier auf der Welt platziert
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //-----hier kommt der ProgrammierCode des Roboters hin
           
        }



        protected override void OnPaint(PaintEventArgs e)
        {

            Graphics g = this.CreateGraphics();
            g.DrawImage(w.gibWeltBild(), 0, 0);
        }


        private void Initialize()
        {
            this.ClientSize = new Size(w.gibBreite() * 42 + 50 + 150, w.gibHoehe() * 42 + 100);
            DoubleBuffered = true;
            button1.Left = ClientSize.Width - 100;
            w.HintergrundFarbe = this.BackColor;
            w.BitmapGeaendert += OnPaint;
        }

        
    }
}
